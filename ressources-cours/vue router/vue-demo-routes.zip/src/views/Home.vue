<template>
  <div class="home">
  	<div>
  		<p>ESSAI ROUTEUR</p>
  		<router-link to="/about/daniel">Aller à About</router-link>
  		<p><button @click="testRouter">Route vers Albert</button></p>
  		<p><button @click="testRouterWithQuery">Route avec query</button></p>
  	</div>

    <img alt="Vue logo" src="../assets/logo.png">
    <HelloWorld msg="Welcome to Your Vue.js App"/>
  	
  </div>
</template>

<script>
// @ is an alias to /src
import HelloWorld from '@/components/HelloWorld.vue';

export default {
  name: 'home',
  components: {
    HelloWorld
  },
  methods: {
  	testRouter: function() {
  		this.$router.push({ name: 'about', params: { username: 'Albert' }
  		})
  	},
  	testRouterWithQuery: function () {
  		this.$router.push({ name: 'about', query: { nom: 'Daniel Vermonden' } 
  		})
  	}	
  }

}
</script>

<template>
  <div class="about">
    <h1>This is an about page</h1>
    <div>
    	<p>TEST ROUTEUR : {{username()}} ou bien {{ $route.params.username }}</p>
    </div>
    <div>
    	<p>TEST ROUTEUR : {{getNom()}}</p>
    </div>
    <div>
    	<p>TEST MIXIN</p>
    	<p>Nom : {{nom}}</p>
    	<p>{{ecrireNom()}}</p>
    </div>

  </div>
</template>

<script>
// @ is an alias to /src
import monMixin from '@/components/mixins/monMixin.js'

export default {
  name: 'about',
  mixins: [monMixin],
  methods: {
  	username() {
      return this.$route.params.username
    },
    getNom() {
      return this.$route.query.nom
    }	
  }
}
</script>

